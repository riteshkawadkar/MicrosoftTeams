# MicrosoftTeams

Update below with your details in [DeleteChats.java](https://github.com/riteshkawadkar/MicrosoftTeams/blob/master/src/main/java/util/DeleteChats.java)

## Profile Path
Type chrome://version to get the profilePath 

static String profilePath= "C:\\Users\\rites\\AppData\\Local\\Google\\Chrome\\User Data";


## Chat URL
Provide chat URL in below variable

static String chatURL = "https://teams.microsoft.com/_?culture=en-in&country=IN&lm=deeplink&lmsrc=NeutralHomePageWeb&cmpid=WebSignIn#/conversations/19:meeting_ZTlkNjBlZDAtZDQ0YS00MzkzLWI4MWQtNWM5ODI2MWIzYmVi@thread.v2?ctx=chat";


## UserName
Provide the name of the person whose chat you want to delete

static String username = "Ritesh Kawadkar";
